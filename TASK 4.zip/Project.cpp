﻿
#include <iostream>
#include <cassert>
using namespace std;

class Engine {

	char* _engine = nullptr;
	char* _company = nullptr;
	float _volume;

public:
	Engine()
	{
		this->_engine = nullptr;
		this->_company = nullptr;
		_volume = 0;
	}

	Engine(const char* engine, const char* company, float volume)
	{
		setEngine_no(engine);
		setCompany(company);
		_volume = volume;
	}

	void setEngine_no(const char* engine) {
		if (engine == nullptr)
		{
			assert(!"!! ERROR !!");
		}
		else if (_engine != nullptr)
		{
			delete[] _engine;
		}

		size_t len = strlen(engine) + 1;
		_engine = new char[len];
		strcpy_s(_engine, len, engine);
	}

	void setCompany(const char* company) {
		if (company == nullptr)
		{
			assert(!"!! ERROR !!");
		}
		else if (_company != nullptr)
		{
			delete[] _company;
		}

		size_t len = strlen(company) + 1;
		_company = new char[len];
		strcpy_s(_company, len, company);
	}

	void print() {
		cout << "Engine : " << _engine << endl;
		cout << "Company : " << _company << endl;
		cout << "Volume : " << _volume << endl;
	}
};



class Gallery {

	char* _model = nullptr;
	char* _vendor = nullptr;
	Engine _engine;

public:
	Gallery()
	{
		this->_model = nullptr;
		this->_vendor = nullptr;

	}

	Gallery(const char* model, const char* vendor, Engine engine)
	{
		setModel(model);
		setVendor(vendor);
		_engine = engine;
	}

	void setModel(const char* model) {

		if (model == nullptr)
		{
			assert(!"!! ERROR !!");
		}
		else if (_model != nullptr)
		{
			delete[] _model;
		}

		size_t len = strlen(model) + 1;
		_model = new char[len];
		strcpy_s(_model, len, model);
	}

	void setVendor(const char* vendor) {
		if (vendor == nullptr)
		{
			assert(!"!! ERROR !!");
		}
		else if (_vendor != nullptr)
		{
			delete[] _vendor;
		}

		size_t len = strlen(vendor) + 1;
		_vendor = new char[len];
		strcpy_s(_vendor, len, vendor);
	}

	void printT() {
		_engine.print();
		cout << "Model : " << _model << endl;
		cout << "Vendor : " << _vendor << endl;
	}
};



class Car : public Gallery {

	size_t id;
	static size_t staticId;
	char* _model = nullptr;
	char* _vendor = nullptr;
	Engine _engine;
	bool _hasSpoiler;

public:
	Car()
	{
		id = staticId++;
		this->_model = nullptr;
		this->_vendor = nullptr;
	}

	Car(const char* model, const char* vendor, Engine engine, bool hasSpoiler):Gallery(model, vendor, engine)
	{
		id = ++staticId;
		_hasSpoiler = hasSpoiler;
	}

	void setModel(const char* model) {
		if (model == nullptr)
		{
			assert(!"!! ERROR !!");
		}
		else if (_model != nullptr)
		{
			delete[] _model;
		}

		size_t len = strlen(model) + 1;
		_model = new char[len];
		strcpy_s(_model, len, model);
	}

	void setVendor(const char* vendor) {

		if (vendor == nullptr)
		{
			assert(!"!! ERROR !!");
		}
		else if (_vendor != nullptr)
		{
			delete[] _vendor;
		}

		size_t len = strlen(vendor) + 1;
		_vendor = new char[len];
		strcpy_s(_vendor, len, vendor);
	}

	void printC() {
		printT();
		cout << "Spoiler: " << _hasSpoiler << endl;
	}
};



size_t Car::staticId = 0;



class Ship : public Gallery {

	bool _price;

public:
	Ship()
	{
		_price = NULL;
	}

	Ship(const char* model, const char* vendor, Engine engine, bool newprice):Gallery(model, vendor, engine)
	{
		_price = newprice;
	}

	void printS() {
		printT();
		cout << "Price: " << _price << endl;
	}
};



class Airplane : public Gallery {

	int _sizePassengers;

public:
	Airplane()
	{
		_sizePassengers = 0;
	}

	Airplane(const char* model, const char* vendor, Engine engine, int sizePassenger):Gallery(model, vendor, engine)
	{
		_sizePassengers = sizePassenger;
	}

	void printP() {
		printT();
		cout << "Capacity: " << _sizePassengers << endl;
	}
};


void main() {

	cout  << "+-----------------------------+" << endl << endl;
	Engine g1("MC", "AMG", 5.5);
	Car* c1 = new Car("Mercedes", "CLS 63", g1, true);
	c1->printC();
	cout << endl << "+-----------------------------+" << endl;



	Engine g2("KW", "MT", 400.0);
	Car* c2 = new Car("Kawasaki", "Ninja", g2, true);
	c2->printC();
	cout << endl << "+-----------------------------+" << endl;



	Engine g3("YT", "FG", 1360.0 );
	Car* c3 = new Car("Auri", "Abacus 70", g3, true);
	c3->printC();
	cout << endl << "+-----------------------------+" << endl;

	

}

